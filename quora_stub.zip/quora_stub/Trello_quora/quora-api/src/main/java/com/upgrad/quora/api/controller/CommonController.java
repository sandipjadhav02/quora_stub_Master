package com.upgrad.quora.api.controller;

public class CommonController {
}
