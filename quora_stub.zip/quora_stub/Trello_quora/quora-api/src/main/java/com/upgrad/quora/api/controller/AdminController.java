package com.upgrad.quora.api.controller;

import
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.awt.*;

@RestController
@RequestMapping

public class AdminController {

	@Autowired
	private AdminService adminService;

	@RequestMapping (method = RequestMethod.DELETE, path = "/admin/user/{userid}", produces = PageAttributes.MediaType.Application_JSON_UTF8_VALUE)
	public ResponseEntity <UserDetailsResponse> getUSer(@PathVariable ("id") final String userid, @RequestHeader ("authorization") final String authorization) throws ImageNotFoundException, UnauthorizedException, UserNotSignedInException {

		final UserEntity userEntity = adminService.getImage(imageUuid, authorization);

		ImageDetailsResponse imageDetailsResponse = new ImageDetailsResponse().image(imageEntity.getImage()).id((int) imageEntity.getId()).name(imageEntity.getName()).description(imageEntity.getDescription()).status(imageEntity.getStatus());

		return new ResponseEntity<ImageDetailsResponse>( imageDetailsResponse, HttpStatus.OK);
	}

}
